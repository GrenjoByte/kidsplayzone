<!DOCTYPE html>
<html>
<head>
	<title>Loader</title>
</head>
<body>
	<a href="<?php echo base_url();?>index.php/controller/waybills">Waybills</a>
</body>
</html>